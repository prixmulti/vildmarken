
import React, { useState, useEffect } from 'react';

interface SplashScreenProps {
  onFinish: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);

  const wildNatureImgUrl = "https://images.unsplash.com/photo-1511497584788-8767fe78e82a?auto=format&fit=crop&q=80&w=1200";

  useEffect(() => {
    // Øjeblikkelig klar
    const timer = setTimeout(() => setIsLoaded(true), 50);
    return () => clearTimeout(timer);
  }, []);

  const handleEnter = () => {
    setIsVisible(false);
    setTimeout(onFinish, 200); // Hurtigst mulige overgang
  };

  return (
    <div 
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center transition-all duration-200 ease-in-out ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'
      }`}
    >
      {/* Background Image with stronger Overlay and Blur */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img 
          src={wildNatureImgUrl} 
          alt="Nørholm Vildmark" 
          className={`w-full h-full object-cover transition-transform duration-[2500ms] ${isLoaded ? 'scale-110' : 'scale-100'}`}
        />
        {/* Øget blur og mørkere overlay for at "dushe" kortet/baggrunden mere */}
        <div className="absolute inset-0 bg-emerald-950/70 backdrop-blur-md"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-950 via-transparent to-emerald-950/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-sm px-8 flex flex-col items-center text-center">
        <div className={`mb-10 p-8 rounded-[2.5rem] bg-white shadow-2xl transition-all duration-500 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <img 
            src="https://naturaudio.dk/NaturAudio_logo.png" 
            alt="NaturAudio" 
            className="h-24 w-auto block"
          />
        </div>

        <div className={`space-y-2 transition-all duration-500 delay-100 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <h1 className="text-4xl font-black text-white tracking-tight leading-tight uppercase">
            Velkommen til <br/>
            <span className="text-emerald-400">Nørholm Vildmark</span>
          </h1>
        </div>

        <button 
          onClick={handleEnter}
          disabled={!isLoaded}
          className={`mt-12 py-5 px-14 bg-emerald-600 text-white rounded-2xl font-black text-lg tracking-[0.1em] shadow-[0_20px_40px_rgba(5,150,105,0.4)] transition-all duration-300 delay-200 active:scale-95 hover:bg-emerald-500 ${
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          START TUREN
        </button>
      </div>
    </div>
  );
};

export default SplashScreen;
