
import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, RotateCcw, Volume2, MapPin } from 'lucide-react';
import { AudioPoint } from '../types';

interface InfoPanelProps {
  point: AudioPoint | null;
  userLocation: [number, number] | null;
  onClose: () => void;
}

const URN_PATH = "M5.42,1.11c0,.74,1.73,2.21,3.94,3.5,3.7,1.84,3.45,3.14-2.71,12.36L0,27.3l6.41,8.67c3.7,4.61,6.16,9.96,5.92,11.62-.49,2.58,1.48,3.14,10.35,3.14s10.84-.55,10.35-3.14c-.25-1.66,2.22-7.01,5.92-11.62l6.41-8.67-6.65-10.33c-6.16-9.22-6.41-10.51-2.71-12.36C42.89.74,40.42,0,22.68,0,13.31,0,5.42.55,5.42,1.11Z";

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371e3;
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
};

const UrnIcon = ({ size = "1.5rem", color = "currentColor" }) => (
  <svg viewBox="0 0 45.35 50.73" width={size} height={size} fill={color} className="inline-block"><path d={URN_PATH} /></svg>
);

const InfoPanel: React.FC<InfoPanelProps> = ({ point, userLocation, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const isArchaeology = point?.audioSrc === 'urne';

  useEffect(() => {
    if (!point || isArchaeology) {
      if (audioRef.current) { audioRef.current.pause(); setIsPlaying(false); }
      return;
    }
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = point.audioSrc;
      audioRef.current.load();
      setIsPlaying(false);
      setProgress(0);
      setCurrentTime(0);
    }
  }, [point, isArchaeology]);

  const togglePlay = () => {
    if (!audioRef.current || isArchaeology) return;
    if (isPlaying) audioRef.current.pause();
    else audioRef.current.play().catch(console.error);
    setIsPlaying(!isPlaying);
  };

  const onTimeUpdate = () => {
    if (!audioRef.current) return;
    const cur = audioRef.current.currentTime;
    const dur = audioRef.current.duration;
    setCurrentTime(cur);
    setDuration(dur || 0);
    setProgress((cur / dur) * 100 || 0);
  };

  const formatTime = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!point) return null;

  const distance = userLocation && point 
    ? Math.round(calculateDistance(userLocation[0], userLocation[1], point.lat, point.lng))
    : null;

  return (
    <div 
      className={`fixed bottom-4 left-4 right-4 z-[2000] bg-white rounded-[2.5rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.3)] transition-all duration-500 ease-out transform flex flex-col ${point ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0 pointer-events-none'}`}
      style={{ maxHeight: '85vh' }}
    >
      {!isArchaeology && <audio ref={audioRef} onTimeUpdate={onTimeUpdate} onEnded={() => setIsPlaying(false)} onLoadedMetadata={onTimeUpdate} />}
      <div className="flex justify-center p-3 cursor-pointer shrink-0" onClick={onClose}><div className="w-10 h-1 bg-stone-200 rounded-full"></div></div>
      <div className="px-6 shrink-0">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1 pr-4">
            <h2 className="text-2xl font-black text-[#1a3a32] leading-tight mb-1">{point.title}</h2>
            <div className="flex items-center gap-1.5 text-[#1a3a32]/40 font-bold uppercase tracking-[0.1em] text-[10px]">
              {isArchaeology ? (<><UrnIcon size="14px" /><span>Arkæologisk fund</span></>) : (<><Volume2 size={12} strokeWidth={3} /><span>Audiofortælling</span></>)}
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-full bg-stone-100 text-stone-600 shrink-0"><X size={18} /></button>
        </div>
        {!isArchaeology ? (
          <div className="bg-[#1a3a32] rounded-2xl p-4 text-white shadow-xl mb-4">
            <div className="flex items-center gap-4">
              <button onClick={togglePlay} className="w-11 h-11 flex-shrink-0 flex items-center justify-center rounded-full bg-white text-[#1a3a32]">{isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}</button>
              <div className="flex-1 min-w-0">
                <div className="relative h-1 w-full bg-white/10 rounded-full overflow-hidden mb-2">
                  <div className="absolute left-0 top-0 h-full bg-white rounded-full transition-all" style={{ width: `${progress}%` }}></div>
                </div>
                <div className="flex justify-between items-center text-[10px] font-bold text-white/40">
                  <div className="flex items-center gap-1.5"><span className="text-white/60">{formatTime(currentTime)}</span><span>/</span><span>{formatTime(duration)}</span></div>
                  <button onClick={() => { if(audioRef.current) audioRef.current.currentTime = 0 }} className="p-1 hover:text-white"><RotateCcw size={12} /></button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-amber-50 border border-amber-100/50 rounded-2xl p-4 mb-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center shadow-sm"><UrnIcon size="20px" /></div>
            <div><p className="text-[10px] font-black text-amber-900/40 uppercase tracking-widest">Fortidsminde</p><p className="text-[13px] font-medium text-amber-900/80">Historiske spor fra fortiden.</p></div>
          </div>
        )}
      </div>
      <div className="px-6 flex-1 overflow-y-auto scrollbar-hide py-2 min-h-0">
        <div className="space-y-2">
          <h3 className="text-[10px] font-black text-[#1a3a32]/30 uppercase tracking-[0.2em]">Beskrivelse</h3>
          <p className="text-stone-700 leading-relaxed text-[15px]">{point.description}</p>
        </div>
      </div>
      {/* Diskret afstandsangivelse i bunden i stedet for Google Maps knappen */}
      <div className="px-6 pb-6 pt-3 shrink-0">
        {distance !== null ? (
          <div className="flex items-center justify-center gap-2 py-3 border-t border-stone-100">
            <MapPin size={12} className="text-emerald-600 opacity-60" />
            <span className="text-[11px] font-bold text-stone-400 tracking-wider uppercase">
              Du er <span className="text-emerald-700">{distance} meter</span> væk (fugleflugtslinie)
            </span>
          </div>
        ) : (
          <div className="py-2"></div>
        )}
      </div>
    </div>
  );
};

export default InfoPanel;
