
import { AudioPoint, PolygonCoords } from './types';

export const AUDIO_POINTS: AudioPoint[] = [
  {
    id: 1,
    lat: 55.6845527516564,
    lng: 8.604011535644533,
    title: "Nørholms Forvandling",
    description: "Siden 1. januar 2026 har Hempel Fonden omdannet Nørholm Gods til en vild natur-hub, hvor menneskets styring fjernes, så naturen kan genfinde sin egen rytme og skabe plads til trængte arter.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/rewilding_speaks/noerholms-forvandling.mp3",
    category: 'Rewild'
  },
  {
    id: 2,
    lat: 55.67873378886616,
    lng: 8.621392250061037,
    title: "Tørvegravernes hårde liv",
    description: "I århundreder var tørvegravning en hård nødvendighed for familierne omkring Nørholm Hede. De små vandhuller vi ser i dag, gemmer på historier om slidsomt arbejde og overlevelse.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/historie_speaks/toervegravernes-haarde-liv.mp3",
    category: 'Historie'
  },
  {
    id: 3,
    lat: 55.686705911354146,
    lng: 8.625340461730959,
    title: "Varde Å genslynget",
    description: "Ved Nørholm Gods er Varde Å ført tilbage til sit naturlige, snoede forløb. Genslyngningen har givet nyt liv til åen, styrket biodiversiteten og genskabt et historisk landskab, hvor natur og vand igen arbejder sammen.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/heden_speaks/varde-aa-genslyngning.mp3",
    category: 'Natur'
  },
  {
    id: 4,
    lat: 55.672962361614594,
    lng: 8.5973596572876,
    title: "120 års stilstand",
    description: "Siden 1895 har Nørholm Hede udviklet sig til en sjælden, moden hede med over hundrede års forskningsdata fra samme sted. Naturen følger ikke en lige linje – hedelyngen pulserer og tilpasser sig, mens træerne kun langsomt rykker ind.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/heden_speaks/120-aars-stilhed.mp3",
    category: 'Natur'
  },
  {
    id: 5,
    lat: 55.67753601549482,
    lng: 8.592896461486818,
    title: "Økosystemets Maskinrum",
    description: "Rewilding er projektets kerne. Ved at genindføre store græssere genskabes naturlige dynamikker, der har manglet i århundreder, og som fungerer som et aktivt værn mod den globale naturkrise.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/rewilding_speaks/oekosystemets-maskinrum.mp3",
    category: 'Rewild'
  },
  {
    id: 6,
    lat: 55.6767677274091,
    lng: 8.60909700393677,
    title: "Gravhøjene",
    description: "Ti gravhøje knejser stadig på Nørholm Hede - stumme vidner fra en tid for over 3000 år siden. De fortæller historien om bronzealderens mennesker, der lagde deres døde til hvile på højdedrag med udsigt over landskabet.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/historie_speaks/gravhoejene-monumenter-fra-bronzealderen.mp3",
    category: 'Historie'
  },
  {
    id: 7,
    lat: 55.68080258375805,
    lng: 8.600792884826662,
    title: "Den urørte hede",
    description: "Nørholm Hede har ligget næsten uforstyrret siden 1895 – over 120 år uden menneskelig indblanding. I modsætning til plejede heder har den udviklet en rig mosaik af plantesamfund, skabt af myrernes naturlige arbejde, og hedelyngen regenererer stadig sig selv naturligt.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/heden_speaks/den-uroerte-hede.mp3",
    category: 'Natur'
  },
  {
    id: 8,
    lat: 55.69756667343924,
    lng: 8.595256805419924,
    title: "En National Vision",
    description: "Nørholm indgår i et større netværk sammen med Molslaboratoriet og Asnæs-halvøen – tre vildmarker, der tilsammen skal inspirere og dokumentere naturgenopretning i hele Danmark.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/rewilding_speaks/en-national-vision.mp3",
    category: 'Rewild'
  },
  {
    id: 9,
    lat: 55.68928228934072,
    lng: 8.582532405853273,
    title: "Borgervidenskab i felten",
    description: "Besøgende kan bidrage til forskningen ved at registrere naturobservationer på Arter.dk, og dermed hjælpe med at dokumentere biodiversitetens udvikling, når vildskaben overtager.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/rewilding_speaks/borgervidenskab-i-felten.mp3",
    category: 'Rewild'
  },
  {
    id: 10,
    lat: 55.684576945120526,
    lng: 8.620705604553224,
    title: "Respekt for Vildskaben",
    description: "Som gæst i naturen skal du følge områdets skilte og holde hunden i snor, så det spirende dyreliv og de vilde processer beskyttes.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/rewilding_speaks/respekt-for-videnskaben.mp3",
    category: 'Rewild'
  },
  {
    id: 11,
    lat: 55.68754053126214,
    lng: 8.57834815979004,
    title: "Rundhøje ved Nørholm",
    description: "Dette område indeholder flere velbevarede rundhøje fra bronzealderen. Højene vidner om en tidlig bosættelse og har tjent som gravsteder for områdets magtfulde slægter.",
    audioSrc: "urne",
    category: 'Historie'
  },
  {
    id: 12,
    lat: 55.69500293484772,
    lng: 8.607273101806642,
    title: "Te-tårnets fundament",
    description: "Her stod fruens te-tårn i fordums tid. I dag er der kun fundamentet og de arkæologiske spor tilbage, som fortæller om godsets herskabelige fritidsliv.",
    audioSrc: "urne",
    category: 'Historie'
  },
  {
    id: 13,
    lat: 55.68576240652881,
    lng: 8.600556850433351,
    title: "Nørholm Gods",
    description: "Andreas Charles Teilmann var ikke bare en godsejer - han var en visionær, der bragte oplysningstidens ideer til Vestjylland. Hans arv kan stadig ses overalt omkring Nørholm.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/historie_speaks/ac-teilmann-oplysningstiden-paa-noerholm.mp3",
    category: 'Historie'
  },
  {
    id: 14,
    lat: 55.681504255420386,
    lng: 8.61381769180298,
    title: "Fredning af heden",
    description: "I 1913 skete noget bemærkelsesværdigt: Nørholm Hede blev fredet af sin egen ejer, Ingeborg Christiane Rosenørn-Teilmann. Det var 24 år før den store automatiske fredning af fortidsminder i 1937.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/historie_speaks/fredningen-hvordan-heden-blev-reddet.mp3",
    category: 'Historie'
  },
  {
    id: 15,
    lat: 55.688447706609445,
    lng: 8.596758842468263,
    title: "Stavnsbåndets skygge",
    description: "I 1733 indførtes stavnsbåndet - en lov der skulle binde unge mænd til jorden. Men på Nørholm og i Vestjylland virkede den ikke som planlagt. Mange fandt måder at flygte på.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/historie_speaks/stavnsbaandets-skygge-over-heden.mp3",
    category: 'Historie'
  },
  {
    id: 16,
    lat: 55.68254464195652,
    lng: 8.626885414123537,
    title: "Myrernes hede",
    description: "Tusindvis af myrekolonier har gennem generationer bygget et bølgende landskab af tuer og dale på heden. Hver tue skaber sit eget mikroklima og levested, hvilket giver en langt større biodiversitet end på de ensformige, maskindrevne plejede heder.",
    audioSrc: "https://naturaudio.dk/vildmarken/audio/heden_speaks/myrernes-hede.mp3",
    category: 'Natur'
  }
];

export const ROUTE_COORDINATES: [number, number][] = [];

export const FOREST_BOUNDARY: PolygonCoords[] = [
  // Hovedareal Nord
  [
    [55.70046022, 8.58868715], [55.7005008, 8.58545058], [55.69906824, 8.58207997], [55.69899892, 8.58191674],
    [55.69805409, 8.57970871], [55.69657855, 8.5762641], [55.69634336, 8.57574616], [55.69579532, 8.5751883],
    [55.69533538, 8.57440582], [55.6948444, 8.57441495], [55.69429279, 8.57519093], [55.6937851, 8.57693595],
    [55.69310692, 8.57704178], [55.69256716, 8.57745472], [55.69181397, 8.57761465], [55.69106461, 8.57708428],
    [55.69048463, 8.57652819], [55.69017873, 8.57621989], [55.68966891, 8.57536477], [55.68881639, 8.57466835],
    [55.68815613, 8.57365298], [55.68769661, 8.57283763], [55.68712486, 8.57249732], [55.68659359, 8.57261686],
    [55.68618958, 8.57382511], [55.68598297, 8.57560841], [55.6854104, 8.57657338], [55.68560828, 8.57806821],
    [55.68471699, 8.57902712], [55.68449069, 8.57981801], [55.68407974, 8.5796589], [55.68350519, 8.57974224],
    [55.68308747, 8.57953062], [55.68285837, 8.57905656], [55.68233324, 8.57874648], [55.68194274, 8.5795135],
    [55.6816635, 8.57911353], [55.6814347, 8.57948366], [55.68106209, 8.57987066], [55.68119352, 8.58004838],
    [55.68062588, 8.58099884], [55.68046978, 8.58115865], [55.68013953, 8.58121302], [55.68022153, 8.58140316],
    [55.68042998, 8.58168708], [55.68030002, 8.58192831], [55.67978628, 8.58207016], [55.68033228, 8.58324913],
    [55.68060611, 8.58335864], [55.68157649, 8.58375185], [55.68276669, 8.58420351], [55.68361052, 8.58456853],
    [55.68473232, 8.58504326], [55.68580725, 8.58547756], [55.68655773, 8.58571522], [55.68727663, 8.58612757],
    [55.68824418, 8.58654235], [55.68949895, 8.58702365], [55.69093962, 8.58761592], [55.69269594, 8.58785926],
    [55.69340292, 8.58863651], [55.69462729, 8.58913397], [55.69613407, 8.58976282], [55.69824447, 8.59062053],
    [55.7003555, 8.59142945], [55.70046022, 8.58868715]
  ],
  // Centralt/Sydligt Areal
  [
    [55.68559911, 8.58561561], [55.68550783, 8.58592851], [55.68425266, 8.58542662], [55.68278665, 8.58483908],
    [55.68082634, 8.58405792], [55.68113683, 8.584742], [55.681759, 8.58609855], [55.68227105, 8.58719635],
    [55.68282949, 8.58824696], [55.68323217, 8.58873872], [55.68364098, 8.58949766], [55.68405132, 8.59022709],
    [55.68449877, 8.59099729], [55.68505882, 8.59248005], [55.68563191, 8.59442054], [55.68595434, 8.59539258],
    [55.68631735, 8.59639686], [55.68683656, 8.59754303], [55.68748615, 8.5989137], [55.68774565, 8.59954522],
    [55.68807839, 8.60030494], [55.68850211, 8.60127369], [55.68923563, 8.60284235], [55.68966324, 8.60361691],
    [55.69013758, 8.60419884], [55.6905853, 8.60446862], [55.69156001, 8.60470449], [55.692231, 8.60493106],
    [55.69443224, 8.6053429], [55.69679648, 8.6058027], [55.69858689, 8.60613264], [55.69902583, 8.60603078],
    [55.700557, 8.59628317], [55.70170491, 8.59358979], [55.7028611, 8.59292083], [55.70243579, 8.59257017],
    [55.70088078, 8.59192966], [55.70007457, 8.59158486], [55.69930099, 8.59124098], [55.69833944, 8.59084193],
    [55.69648599, 8.59044365], [55.69565409, 8.58974344], [55.69466285, 8.58969817], [55.69366212, 8.58893021],
    [55.69255182, 8.58860123], [55.69219145, 8.58832472], [55.69206729, 8.58906863], [55.69149257, 8.58802274],
    [55.69108827, 8.58821992], [55.68812613, 8.58666609], [55.68730192, 8.58633253], [55.6865205, 8.58604426],
    [55.68582256, 8.58584742], [55.68559911, 8.58561561]
  ],
  // Østligt Areal
  [
    [55.68820528, 8.62179768], [55.6883429, 8.62113226], [55.68859739, 8.6208412], [55.6885457, 8.62100825],
    [55.68901802, 8.6209185], [55.68911439, 8.6204691], [55.68896393, 8.61945526], [55.68885252, 8.61875573],
    [55.68847637, 8.61850582], [55.6883762, 8.6183007], [55.6884683, 8.61748944], [55.68866301, 8.61702391],
    [55.68857074, 8.61628111], [55.68849844, 8.61556079], [55.68868789, 8.61547777], [55.6891148, 8.61624599],
    [55.68935955, 8.61652554], [55.6895498, 8.61631223], [55.69010409, 8.61542595], [55.69252559, 8.6132089],
    [55.69308603, 8.61259733], [55.6928428, 8.61147453], [55.69248269, 8.61020029], [55.69170971, 8.60848631],
    [55.69011155, 8.60511803], [55.68838887, 8.60147888], [55.68726325, 8.59907272], [55.68616864, 8.59650841],
    [55.68505496, 8.5938938], [55.6838631, 8.59111389], [55.68270943, 8.58930932], [55.68139774, 8.58657596],
    [55.68037346, 8.58447251], [55.67954046, 8.58381378], [55.67940057, 8.58317249], [55.67907751, 8.58309107],
    [55.67889924, 8.58344572], [55.6785805, 8.58339645], [55.67823732, 8.58322939], [55.67754047, 8.58259315],
    [55.67703585, 8.58254225], [55.67448903, 8.58145454], [55.67376521, 8.58467133], [55.67393278, 8.58536309],
    [55.67341214, 8.5866748], [55.67281831, 8.59060861], [55.67169914, 8.59042712], [55.67064355, 8.59099048],
    [55.66958889, 8.59178082], [55.67027834, 8.6001757], [55.67168575, 8.605245], [55.67402819, 8.61375622],
    [55.67700325, 8.62460411], [55.68205534, 8.63452971], [55.68491684, 8.63455034], [55.68737399, 8.63472541],
    [55.6880564, 8.63334038], [55.68864986, 8.6324319], [55.68883827, 8.63214652], [55.68871846, 8.63163377],
    [55.68787622, 8.63098854], [55.68745311, 8.63082562], [55.68726143, 8.63007566], [55.6875607, 8.63004689],
    [55.68804839, 8.63023777], [55.68813288, 8.62997002], [55.68814529, 8.62982595], [55.6881142, 8.62901753],
    [55.6880317, 8.628665], [55.68785782, 8.62840207], [55.6874076, 8.62843339], [55.68716834, 8.62860361],
    [55.68693293, 8.62842577], [55.68696537, 8.62760021], [55.68719658, 8.62724402], [55.68749941, 8.62739146],
    [55.68784591, 8.62752628], [55.68822788, 8.62732969], [55.6884265, 8.62719527], [55.68882629, 8.62652351],
    [55.68872702, 8.62597387], [55.68838568, 8.62574319], [55.68811389, 8.625649], [55.68798489, 8.6251762],
    [55.68794332, 8.62432555], [55.68789155, 8.62415091], [55.68771058, 8.62407116], [55.68761397, 8.62379432],
    [55.68769952, 8.62325632], [55.68789389, 8.62303714], [55.68815467, 8.62311284], [55.68848338, 8.62295238],
    [55.68859496, 8.62257182], [55.68850554, 8.62228964], [55.68820528, 8.62179768]
  ],
  // Små sydvestlige lumper
  [
    [55.68004139, 8.58394201], [55.68048169, 8.58435046], [55.67988981, 8.58328979], [55.67954053, 8.58320741],
    [55.68004139, 8.58394201]
  ],
  [
    [55.67951353, 8.58244118], [55.67955079, 8.58288969], [55.680048, 8.58313431], [55.67966704, 8.58216588],
    [55.67951353, 8.58244118]
  ],
  [
    [55.67892048, 8.5822096], [55.67898384, 8.58201189], [55.67882545, 8.58202886], [55.67875924, 8.58219777],
    [55.67866612, 8.5824293], [55.67907048, 8.58260407], [55.6793674, 8.58276153], [55.67914563, 8.58241769],
    [55.6790621, 8.58230705], [55.67892048, 8.5822096]
  ],
  // Midt-Øst parcel
  [
    [55.69884781, 8.60644961], [55.69773879, 8.60622581], [55.69677765, 8.60604706], [55.6958798, 8.60588124],
    [55.69499413, 8.60571693], [55.69441533, 8.60562357], [55.69354748, 8.60546275], [55.69321236, 8.60538026],
    [55.69266843, 8.60526329], [55.69220623, 8.60518122], [55.69203452, 8.60521037], [55.69153581, 8.60514311],
    [55.69108829, 8.60506513], [55.69067592, 8.60502182], [55.69051332, 8.60509795], [55.69049972, 8.6054385],
    [55.69064368, 8.60588883], [55.69136321, 8.60740795], [55.69221284, 8.60921638], [55.69266904, 8.61033707],
    [55.69321202, 8.61245457], [55.69410837, 8.61155219], [55.69884781, 8.60644961]
  ]
];

export const APP_THEME = {
  primary: "#1A3A32",
  secondary: "#2D5A4C",
  accent: "#EAB308",
  background: "#F4F7F2",
  white: "#FFFFFF",
  text: "#1A3A32",
  categories: {
    Alle: "#1A3A32",
    Historie: "#78350F",
    Natur: "#065F46",
    Rewild: "#1E40AF"
  }
};
